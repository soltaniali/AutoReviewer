import os

def calculate_eval(expression):
    # Security issue: eval()
    return eval(expression)

def divide(a, b):
    # Bug: No zero division check
    return a / b
