from math_ops import calculate_eval, divide

def main():
    expr = input('Enter expression: ')
    print('Result:', calculate_eval(expr))
    
    # Syntax bug
    print 'Division result: ', divide(10, 0)
    
if __name__ == '__main__':
    main()
